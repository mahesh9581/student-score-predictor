import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# ----------- Data -----------
X = np.array([[1.5], [2.0], [3.2], [4.0], [5.5], [6.1], [7.0], [8.3]])
y = np.array([20, 25, 45, 50, 75, 80, 85, 95])

# Train Model
model = LinearRegression()
model.fit(X, y)

# ----------- Streamlit UI -----------
st.set_page_config(page_title="Student Score Predictor", layout="centered")
st.title("📘 Student Score Predictor")
st.markdown("Predict student exam score based on number of study hours using Linear Regression.")

# Input
hours = st.number_input("📚 Enter number of study hours:", min_value=0.0, step=0.1)

# Predict button
if st.button("🎯 Predict Score"):
    prediction = model.predict([[hours]])[0]
    st.success(f"Predicted Score for {hours} hours: **{prediction:.2f}**")

    # Plot regression
    fig, ax = plt.subplots()
    ax.scatter(X, y, color='blue', label="Actual Scores")
    ax.plot(X, model.predict(X), color='red', label="Regression Line")
    ax.scatter(hours, prediction, color='green', s=100, label="Your Prediction")
    ax.set_xlabel("Hours Studied")
    ax.set_ylabel("Score")
    ax.legend()
    st.pyplot(fig)

# Footer
st.markdown("---")
st.markdown("Built with ❤️ using Streamlit | Linear Regression Demo")
